import {
  Context,
  APIGatewayProxyHandler,
  APIGatewayProxyEvent,
} from 'aws-lambda';
import { proxy, createServer } from 'aws-serverless-express';
import { Server } from 'http';
const express = require('express');
import * as dynamoose from 'dynamoose';
import { ExpressAdapter } from '@nestjs/platform-express';
import * as AWS from 'aws-sdk';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { UserSchema } from './Domain/entities/user.schema';
import { TaskSchema } from './Domain/entities/task.schema';
const dynamoDb = new AWS.DynamoDB();

let cachedServer: Server;

async function bootstrapServer() {
  if (!cachedServer) {
    const expressApp = express();
    expressApp.use(
      (req, res, next) => {
        res.setHeader('Access-Control-Allow-Origin', '*'); // Cho phép tất cả các domain
        res.setHeader('Access-Control-Allow-Methods', 'OPTIONS,GET,POST,PUT,DELETE'); // Các phương thức HTTP được phép
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization'); // Các header được phép
        next();
      },
    );
    expressApp.use(express.json({ limit: '10mb' }));
    const app = await NestFactory.create(
      AppModule,
      new ExpressAdapter(expressApp),
      {
        cors: true,
      },
    );

    // prefix
    app.setGlobalPrefix('/treeview/api');
    // pipes
    // app.useGlobalPipes(
    //   new ValidationPipe({
    //     transform: true,
    //   }),
    // );
    // exception filter
    // app.useGlobalFilters(new AllExceptionFilter(new LoggerService()));
    // // interceptors
    // app.useGlobalInterceptors(new LoggingInterceptor(new LoggerService()));
    // app.useGlobalInterceptors(new ResponseInterceptor());

    await app.init();
    cachedServer = createServer(expressApp);
  }
  return cachedServer;
}
// lambda fn
export const handler: APIGatewayProxyHandler = async (
  event: APIGatewayProxyEvent,
  context: Context,
) => {
  
  const tablePrefix = 'vantest'; // Define your prefix or get it from environment
  const userTable = `${tablePrefix}-users`;
  const taskTable = `${tablePrefix}-tasks`;

  // Set Dynamoose models
  const userModel = dynamoose.model(userTable, UserSchema);
  const taskModel = dynamoose.model(taskTable, TaskSchema);

  // Function to check if table exists
  const doesTableExist = async (tableName: string) => {
    try {
      const result = await dynamoDb.describeTable({ TableName: tableName }).promise();
      return !!result.Table; // Nếu bảng tồn tại, trả về true
    } catch (error) {
      if (error.code === 'ResourceNotFoundException') {
        return false; // Bảng không tồn tại
      }
      throw error; // Nếu có lỗi khác, ném lỗi ra ngoài
    }
  };

  // Check if user table exists, if not, create it
  const userTableExists = await doesTableExist(userTable);
  if (!userTableExists) {
    console.log(`User table ${userTable} does not exist. Creating table...`);
    await userModel.createTable();  // Create the user table
  } else {
    console.log(`User table ${userTable} already exists.`);
  }

  // Check if task table exists, if not, create it
  const taskTableExists = await doesTableExist(taskTable);
  if (!taskTableExists) {
    console.log(`Task table ${taskTable} does not exist. Creating table...`);
    await taskModel.createTable();  // Create the task table
  } else {
    console.log(`Task table ${taskTable} already exists.`);
  }

  cachedServer = await bootstrapServer();
  return proxy(cachedServer, event, context, 'PROMISE').promise;
};
