export interface IS3Service {
  putObject(key: string, body: Buffer | string): Promise<void>;
  deleteObject(key: string): Promise<void>;
}
