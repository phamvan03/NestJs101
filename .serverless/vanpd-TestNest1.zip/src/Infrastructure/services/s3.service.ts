import { Injectable } from '@nestjs/common';
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
} from '@aws-sdk/client-s3';
import { Readable } from 'stream';
import { ConfigService } from '@nestjs/config';
import { IS3Service } from 'src/Application/common/interfaces/s3.interface';

@Injectable()
export class S3Service implements IS3Service {
  private readonly s3Client: S3Client;
  private readonly bucketName: string;

  constructor(configService: ConfigService) {
    const config = {
      region: 'ap-northeast-1',
    };
    this.s3Client = new S3Client(config);
    this.bucketName = configService.get<string>('s3BucketName') || '';
  }

  async putObject(key: string, body: Buffer | string): Promise<void> {
    try {
      console.log('putObject', this.bucketName);
      const command = new PutObjectCommand({
        Bucket: this.bucketName,
        Key: key,
        Body: body,
      });
      await this.s3Client.send(command);
    } catch (error) {
      console.error(error);
      throw new Error('Put object failed');
    }
  }

  // async getObjectAsString(key: string): Promise<string | null> {
  //   try {
  //     const command = new GetObjectCommand({
  //       Bucket: this.bucketName,
  //       Key: key,
  //     });

  //     const { Body } = (await this.s3Client.send(command)) || {};
  //     if (!Body) {
  //       console.log('Object not found');
  //       return null;
  //     }

  //     return await Body.transformToString();
  //   } catch (error) {
  //     console.error(error);
  //     throw new Error('Get object failed');
  //   }
  // }

  // streamToBuffer(stream: Readable): Promise<Buffer> {
  //   return new Promise((resolve, reject) => {
  //     const chunks: Buffer[] = [];
  //     stream.on('data', (chunk) => chunks.push(chunk));
  //     stream.on('end', () => resolve(Buffer.concat(chunks)));
  //     stream.on('error', reject);
  //   });
  // }

  // async getObjectAsBuffer(key: string): Promise<Buffer> {
  //   try {
  //     const command = new GetObjectCommand({
  //       Bucket: this.bucketName,
  //       Key: key,
  //     });

  //     const { Body } = (await this.s3Client.send(command)) || {};

  //     if (Body instanceof Buffer) {
  //       return Body;
  //     }

  //     if (Body instanceof Readable) {
  //       const buffer = await this.streamToBuffer(Body);
  //       return buffer;
  //     }

  //     throw new Error('Unsupported Body type');
  //   } catch (error) {
  //     console.error(error);
  //     throw new Error('Get object failed');
  //   }
  // }

  async deleteObject(key: string): Promise<void> {
    try {
      const command = new DeleteObjectCommand({
        Bucket: this.bucketName,
        Key: key,
      });
      await this.s3Client.send(command);
    } catch (error) {
      console.error(error);
      throw new Error('Delete object failed');
    }
  }
}
